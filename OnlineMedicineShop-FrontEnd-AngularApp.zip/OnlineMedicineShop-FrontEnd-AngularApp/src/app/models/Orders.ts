export interface Orders{
        firstname:string;
        lastname:string;
        phone:string;
        products:string;
        price:string;
        id:number;
        product_id:number;
        user_id:number;
        date_paid:Date;
        amount_paid:string;
        status:string;
        created_by_id:number;
}