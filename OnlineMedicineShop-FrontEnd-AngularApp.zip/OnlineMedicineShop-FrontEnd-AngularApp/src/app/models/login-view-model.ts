export interface LoginViewModel {
     firstname:string,
     id:number,
     role:string
}
